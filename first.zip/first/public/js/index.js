new Vue({
  el:"#app",
  data:{
    products:[
      {title:"",price:0},
      {title:"",price:0},
      {title:"",price:0}
    ]
  },
  created(){
    axios.get("http://127.0.0.1:3000/index")
    .then(res=>{
      console.log(res.data);
      this.products=res.data;
    })
  }
})