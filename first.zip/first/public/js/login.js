$(function(){
  $("button").click(function(){
    var uname=$("[name=uname]").val();
    var upwd=$("[name=upwd]").val();
    console.log(upwd);
    $.ajax({
        url:"http://127.0.0.1:3000/user/login",
        type:"post",
        data:{uname,upwd},
        success: function(result){
          console.log(result);
          if(result==1){
            alert("登录成功！");
            window.location.href="index.html";
          }
          else
            alert("登录失败！");
        }
      })
})
   /*var xhr=new XMLHttpRequest();
  xhr.onreadystatechange=function(){
    if(xhr.readyState==4&&xhr.status==200){
      var res=xhr.responseText;
      console.log(res);
    }
  }
  xhr.open("post","/user/login",true);
  var input_uname=uname.value;
  var input_upwd=upwd.value;
  xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
  var formdata="uname="+input_uname+"&upwd="+input_upwd;
  xhr.send(formdata);*/
})