$(function(){
  $.ajax({
    url:"header.html",
    type:"get",
    success: function(res){
      $("<link rel='stylesheet' href='./css/header.css'>").appendTo("head");
      $(res).replaceAll("#header");
      var $input=$("#header form>input");
      console.log($input.val());
      var $btnSearch=$input.next();
      $btnSearch.click(function(){
        if($input.val().trim().length>0)
          location.href="search_product.html?txt="+$input.val();
        if(location.search.indexOf("txt")!=-1){
          $input.val(
            decodeURI(location.search.split("=")[1])
          ) 
        }
        console.log($input.val());
      })
    }
  })
  $.ajax({
    url:"footer.html",
    type:"get",
    success: function(res) {
      $("<link rel='stylesheet' href='./css/footer.css'>").appendTo("head");
      $(res).replaceAll("#footer");
    }
  })
})