const express=require("express");
const pool=require("../pool");
const router=express.Router();

router.get('/',(req,res)=>{
  var txt=req.query.txt;
  var pno=req.query.pno;
  if(pno===undefined) pno=0;
  console.log(txt);
  txt=txt.split(" ");
  var arr=txt.map(function(){
    return " title like ? ";
  })
  var titles=arr.join(" and ");
  var sql="SELECT * FROM f_search WHERE "+titles;
  txt.forEach(function(val,i,arr){
    txt[i]=`%${val}%`;
  })
  pool.query(sql,txt,(err,result)=>{
    if(err) throw err;
    var count=result.length;
    var pageCount=Math.ceil(count/12);
    var products=result.slice(pno*12,pno*12+12);
    var output={pno,count,pageCount,products}
    res.send(output);
    //res.send(result);

  })
});
/*          WHERE title LIKE '%?%'            [txt], */
module.exports=router;