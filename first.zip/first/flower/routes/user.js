const express=require("express");
//引入连接池对象
const pool=require("../pool");
//创建一个空的路由
const router=express.Router();
//用户登录
router.post('/login',(req,res)=>{
  var obj=req.body;
  var $uname=obj.uname;
  var $upwd=obj.upwd;
  console.log(obj);
  if(!$uname){
    res.send({code:401,msg:'uname required'});
    return;
  }
  if(!$upwd){
    res.send({code:402,msg:'upwd required'});
    return;
  }
  var sql='SELECT * FROM f_user WHERE uname=? and upwd=?';
  pool.query(sql,[$uname,$upwd],(err,result)=>{
    if(err) throw err;
    if(result.length>0)
      res.send("1")
    else
      res.send("2")
  })
})

module.exports=router;