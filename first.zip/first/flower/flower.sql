SET NAMES UTF8;
DROP DATABASE IF EXISTS flower;
CREATE DATABASE flower CHARSET=UTF8;
USE flower;
/*用户表*/
CREATE TABLE f_user(
    uid INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(32),
    upwd VARCHAR(32),
    email VARCHAR(64),
    phone VARCHAR(16),

    avater VARCHAR(128),   #头像路径
    user_name VARCHAR(32), #用户名
    gender INT             #性别
);
INSERT INTO f_user values(null,"123","123456","1@qq.com","13131646825",null,"lilei",1); 
/*主页商品表*/
CREATE TABLE f_index(
    pid INT PRIMARY KEY AUTO_INCREMENT,#id
    title VARCHAR(32),        #名称
    price DECIMAL(8,2),                #价格
    pic VARCHAR(128)        #图片
)
INSERT INTO f_index values(null,"美丽的季节",269.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_index values(null,"相知相守",179.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_index values(null,"有你很快乐",399.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_index values(null,"美丽人生",259.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_index values(null,"我心宠你",899.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_index values(null,"多彩的世界",499.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_index values(null,"心灵的触动",499.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_index values(null,"天使之吻",299.00,'http://127.0.0.1:5500/images/f01_right.jpg');

/*搜索商品表*/
CREATE TABLE f_search(
    pid INT PRIMARY KEY AUTO_INCREMENT,#id
    title VARCHAR(32),        #名称
    price DECIMAL(8,2),                #价格
    pic VARCHAR(128)        #图片
)
INSERT INTO f_search values(null,"花海",329.00,'http://127.0.0.1:5500/images/s_right01.jpg');
INSERT INTO f_search values(null,"花好月圆",369.00,'http://127.0.0.1:5500/images/s_right02.jpg');
INSERT INTO f_search values(null,"风中花香",999.00,'http://127.0.0.1:5500/images/s_right03.jpg');
INSERT INTO f_search values(null,"花伴伊人",479.00,'http://127.0.0.1:5500/images/s_right04.jpg');
INSERT INTO f_search values(null,"花的海洋",199.00,'http://127.0.0.1:5500/images/s_right05.jpg');
INSERT INTO f_search values(null,"花的恋人",349.00,'http://127.0.0.1:5500/images/s_right06.jpg');
INSERT INTO f_search values(null,"花之恋(新款)",269.00,'http://127.0.0.1:5500/images/s_right07.jpg');
INSERT INTO f_search values(null,"花的祝福",179.00,'http://127.0.0.1:5500/images/s_right08.jpg');
INSERT INTO f_search values(null,"百花齐贺",899.00,'http://127.0.0.1:5500/images/s_right09.jpg');
INSERT INTO f_search values(null,"鲜花·LOVE YOU",189.00,'http://127.0.0.1:5500/images/s_left01.jpg');
INSERT INTO f_search values(null,"鲜花·花伴伊人",479.00,'http://127.0.0.1:5500/images/s_left02.jpg');
INSERT INTO f_search values(null,"鲜花·时光荏苒",299.00,'http://127.0.0.1:5500/images/s_left03.jpg');
INSERT INTO f_search values(null,"鲜花·红色恋歌",249.00,'http://127.0.0.1:5500/images/s_left04.jpg');
INSERT INTO f_search values(null,"美丽的季节",269.00,'http://127.0.0.1:5500/images/f01_right.jpg');
INSERT INTO f_search values(null,"相知相守",179.00,'http://127.0.0.1:5500/images/f02_right.jpg');
INSERT INTO f_search values(null,"有你很快乐",399.00,'http://127.0.0.1:5500/images/f03_right.jpg');
INSERT INTO f_search values(null,"美丽人生",259.00,'http://127.0.0.1:5500/images/f04_right.jpg');
INSERT INTO f_search values(null,"我心宠你",899.00,'http://127.0.0.1:5500/images/f05_right.jpg');
INSERT INTO f_search values(null,"多彩的世界",499.00,'http://127.0.0.1:5500/images/f06_right.jpg');
INSERT INTO f_search values(null,"心灵的触动",499.00,'http://127.0.0.1:5500/images/f07_right.jpg');
INSERT INTO f_search values(null,"天使之吻",299.00,'http://127.0.0.1:5500/images/f08_right.jpg');

/*商品详情表
CREATE TABLE f_pro(
    pid INT PRIMARY KEY AUTO_INCREMENT,
    pname VARCHAR(32),
    price (8),
    #编码 名称 现价  原价  花语  图片  材料信息  原材料
);
/*原材料
CREATE TABLE f_raw(
    #编号 名称 数量
    rid INT PRIMARY KEY AUTO_INCREMENT,
    rname VARCHAR(32),
    rquantity
)
/*收货信息
# 收件人  手机号  地址  */
